package com.fiap.patterns.model;

public interface Imposto {
	
	void calcularImposto(float valor);

}
