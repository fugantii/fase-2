package com.fiap.patterns.view;

public interface TelaImposto {
	
	float getValor();

}
