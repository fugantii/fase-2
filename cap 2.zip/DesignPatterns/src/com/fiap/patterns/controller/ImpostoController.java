package com.fiap.patterns.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import com.fiap.patterns.model.Imposto;
import com.fiap.patterns.view.TelaImposto;

public class ImpostoController implements ActionListener {
	
	private Imposto model;
	private TelaImposto tela;

	@Override
	public void actionPerformed(ActionEvent e) {
		model.calcularImposto(tela.getValor());
		// TODO Auto-generated method stub
	}
	
	public ImpostoController(Imposto model, TelaImposto tela) {
		this.model = model;
		this.tela = tela;
	}
	
	

}
